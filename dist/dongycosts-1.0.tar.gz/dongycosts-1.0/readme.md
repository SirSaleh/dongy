# dongy

Fun Django app for calculation quota of each shared costs per user 

## Dependencies
1. `djangorestframework`
## Install Using pip

 You can install `Dongycosts` Django-app simply using:
 
 > sudo pip install https://github.com/SirSaleh/dongy/raw/master/dist/dongycosts-1.0.tar.gz



