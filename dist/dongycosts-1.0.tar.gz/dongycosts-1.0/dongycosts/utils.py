def test_func():
    print ("hi")
